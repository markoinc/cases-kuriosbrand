const m="/assets/mark-gundrum-pEy-0dKA.png";export{m};
